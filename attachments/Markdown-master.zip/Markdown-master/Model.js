.pragma library

// Qt renders `- [ ]` task items, but only as static glyphs. Swapping them for
// links that carry their own source line number makes them clickable without
// hit-testing the rendered document back to the markdown source.

var TASK = /^(\s*(?:[-*+]|\d+[.)])\s+)\[([ xX])\]/

function renderMarkdown(src) {
  var lines = String(src).split("\n")
  for (var i = 0; i < lines.length; i++) {
    var m = lines[i].match(TASK)
    if (!m) continue
    var box = m[2] === " " ? "☐" : "☑"
    lines[i] = m[1] + "[" + box + "](toggle:" + i + ")" + lines[i].slice(m[0].length)
  }
  return lines.join("\n")
}

// ---------------------------------------------------------------- screens
//
// Note positions are stored per screen, local to that screen's usable area.
// The bar reserves the same strip on every output, so that inset cancels out
// of a screen-to-screen conversion and only the origins matter.

// How far (squared) a point is from the band a screen's notes can occupy —
// its origin plus the *usable* size, since that is the space the coordinates
// above live in. Zero when the point is on that screen.
function screenDistance(s, gx, gy, insetW, insetH) {
  var dx = Math.max(s.x - gx, 0, gx - (s.x + s.width - insetW))
  var dy = Math.max(s.y - gy, 0, gy - (s.y + s.height - insetH))
  return dx * dx + dy * dy
}

// Which screen a note dropped at (gx, gy) belongs to: the one under the
// pointer, or the nearest if the pointer is not over any.
//
// Nearest, not null, because the bands do not cover the desktop. The bar's
// strip is a gap between them, and a layout arranged by hand leaves more. A
// drop into one of those used to mean "no screen", which sent the note back to
// the monitor it came from — the drag looking like it simply refused to take.
function screenForDrop(screens, gx, gy, insetW, insetH) {
  // Containment first, and half-open, so the seam belongs to exactly one
  // screen. Distance alone scores the pixel on a band's far edge as zero for
  // both neighbours, and the tie goes to whichever the compositor happened to
  // list first.
  for (var i = 0; i < screens.length; i++) {
    var s = screens[i]
    if (gx >= s.x && gx < s.x + s.width - insetW
      && gy >= s.y && gy < s.y + s.height - insetH) return s
  }
  // Walked in layout order, not the order the compositor handed them over, so
  // that a drop exactly between two screens always settles the same way.
  var ordered = orderedScreens(screens)
  var best = null
  var bestDistance = Infinity
  for (var j = 0; j < ordered.length; j++) {
    var d = screenDistance(ordered[j], gx, gy, insetW, insetH)
    if (d < bestDistance) {
      bestDistance = d
      best = ordered[j]
    }
  }
  return best
}

function bounds(screens) {
  if (!screens.length) return { x1: 0, y1: 0, x2: 0, y2: 0 }
  var b = { x1: Infinity, y1: Infinity, x2: -Infinity, y2: -Infinity }
  for (var i = 0; i < screens.length; i++) {
    var s = screens[i]
    b.x1 = Math.min(b.x1, s.x)
    b.y1 = Math.min(b.y1, s.y)
    b.x2 = Math.max(b.x2, s.x + s.width)
    b.y2 = Math.max(b.y2, s.y + s.height)
  }
  return b
}

// Left to right, and only then top to bottom, so that on an L-shaped layout
// `◀` and `▶` still step the way the glyphs promise: x decides, y is the
// tie-break between screens stacked in the same column. Quickshell hands the
// screens over in connector order, which says nothing about where they sit.
function orderedScreens(screens) {
  return screens.slice().sort(function (a, b) { return (a.x - b.x) || (a.y - b.y) })
}

// The next screen along (dir 1) or back (dir -1), or null at the end of the
// layout. Stepping through the order rather than comparing x: a stacked layout
// has every screen at the same x, and comparing left/right leaves both arrows
// permanently dead with no way to move a note off the monitor it is on.
function adjacentScreen(screens, from, dir) {
  if (!from) return null
  var list = orderedScreens(screens)
  for (var i = 0; i < list.length; i++) {
    if (list[i].name === from.name) return list[i + dir] || null
  }
  return null
}

// Pull a note fully onto a screen of this usable size, keeping it as close as
// it can to where it was asked to go. What the `◀` / `▶` arrows do on their
// own, and the second half of what a drop does.
function clampOnto(x, y, w, h, usableW, usableH) {
  return {
    x: Math.max(0, Math.min(x, Math.max(0, usableW - w))),
    y: Math.max(0, Math.min(y, Math.max(0, usableH - h)))
  }
}

// Re-express a note's position on `to`, keeping it where it visually sits and
// pulling it fully onto the new screen.
function relocate(lx, ly, w, h, from, to) {
  return clampOnto(lx + from.x - to.x, ly + from.y - to.y, w, h, to.usableW, to.usableH)
}

function toggleTask(src, lineIndex) {
  var lines = String(src).split("\n")
  if (!(lineIndex >= 0) || lineIndex >= lines.length) return String(src)
  var m = lines[lineIndex].match(TASK)
  if (!m) return String(src)
  lines[lineIndex] = m[1] + "[" + (m[2] === " " ? "x" : " ") + "]" + lines[lineIndex].slice(m[0].length)
  return lines.join("\n")
}
