import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import Quickshell.Hyprland
import qs.Commons
import qs.Ui
import "Model.js" as Model

// Desktop sticky notes. One layer-shell surface per screen on the Bottom
// layer, masked to the notes on it, so notes sit on the desktop under
// normal windows the way Microsoft Sticky Notes sit on a Windows desktop.
//
// State lives in ~/.local/state/omarchy/omasticky.json.
Item {
  id: root

  readonly property string storePath: Quickshell.env("HOME") + "/.local/state/omarchy/omasticky.json"

  // ponytail: fixed palette cycled by the header dot, not a picker popup.
  // Deliberately theme-independent — a sticky note is yellow.
  readonly property var palette: ["#fff4b8", "#d6f5d6", "#fed8e2", "#e7ddf9", "#cfecfb", "#e6e6e6", "#4b4b4b"]

  // Written back to the store, so `"alwaysOnTop": true` in the JSON pins
  // notes above normal windows instead of leaving them on the desktop.
  property bool alwaysOnTop: false

  // Toggled from the bar widget; persisted so notes stay hidden across a
  // shell restart.
  property bool hidden: false

  function toggleHidden() {
    root.hidden = !root.hidden
    saveTimer.restart()
  }

  // Notes are mutated in place inside this map; `noteIds` is the only
  // reactive handle. That way a keystroke never makes Variants tear a
  // window down and take the cursor with it.
  property var notes: Object.create(null)
  property var noteIds: []
  property bool loaded: false
  property int seq: 0

  // hasOwnProperty, not a bare lookup: note ids come from a hand-editable
  // JSON file, and `constructor` or `__proto__` would otherwise resolve
  // through the prototype chain.
  function noteData(id) {
    var key = String(id)
    return Object.prototype.hasOwnProperty.call(root.notes, key) ? root.notes[key] : null
  }

  function ink(paper) {
    var c = Qt.color(paper)
    return (0.299 * c.r + 0.587 * c.g + 0.114 * c.b) > 0.55 ? "#1f1f1f" : "#f2f2f2"
  }

  function openLink(url) {
    // The note is the user's own text, but a pasted link shouldn't be able to
    // hand xdg-open an arbitrary scheme.
    if (!/^(https?|mailto|file):/i.test(String(url))) return
    Quickshell.execDetached(["xdg-open", String(url)])
  }

  // Bumped only when a note actually changes screen, because it re-evaluates
  // every surface's Repeater model and that rebuilds cards.
  property int placement: 0
  property int topStack: 0

  // Plugging or unplugging a monitor changes which notes are orphaned, and so
  // which surface has to draw them, without touching a single note. The
  // surviving surfaces keep the same `modelData`, so nothing else would make
  // their model re-run and the orphans would stay invisible until a restart.
  //
  // The count, not the screens themselves: Qt adds and removes outputs one at
  // a time, so even swapping one monitor for another moves it. Reading names
  // instead means touching screen objects while they are being torn down.
  readonly property int screenCount: Quickshell.screens.length
  onScreenCountChanged: root.placement++

  // ------------------------------------------------------------------ drag
  // A layer surface is clipped to its own output, so a card dragged toward the
  // seam is sliced off and gone well before it lands — which reads as "it
  // won't go over there". Once a drag starts the card is grabbed to an image,
  // and every *other* screen draws that image at the same layout position: the
  // piece leaving one monitor and the piece arriving on the next meet exactly,
  // and the note crosses in one continuous move.
  //
  // Exactly, because every surface sits the same distance inside its screen —
  // the bar reserves the same strip on each — so `screen.x + local` is one
  // coordinate space shared by all of them. Same assumption the position math
  // in Model.js is built on.
  property string dragId: ""
  property url dragImage: ""
  property int dragGx: 0
  property int dragGy: 0
  property int dragW: 0
  property int dragH: 0
  // The url is only valid while the grab result lives; dropping it on the
  // floor leaves the ghost blank.
  property var dragGrab: null

  function beginDrag(id, item, w, h) {
    root.dragId = String(id)
    root.dragW = w
    root.dragH = h
    root.dragImage = ""
    root.dragGrab = null
    if (!item || typeof item.grabToImage !== "function") return
    // No target size: left alone the grab is taken at the card's real pixel
    // size, scale included. Pinning it to the logical size renders the ghost
    // at half resolution on a scale-2 output, so the half of the note that has
    // crossed would sit next to the sharp half — visible at exactly the seam
    // this is here to hide.
    item.grabToImage(function (result) {
      if (root.dragId !== String(id) || !result || !result.url) return
      root.dragGrab = result
      root.dragImage = result.url
    })
  }

  function endDrag() {
    root.dragId = ""
    root.dragImage = ""
    root.dragGrab = null
  }

  function screenExists(name) {
    if (!name) return false
    var list = Quickshell.screens
    for (var i = 0; i < list.length; i++) if (list[i].name === String(name)) return true
    return false
  }

  // Which notes belong on this screen. Notes naming a screen that is not
  // plugged in fall to the same screen screenFor() falls back to, so
  // unplugging a monitor never strands a note nowhere.
  // `placement` and `ids` are passed in rather than read here: a binding only
  // tracks what it reads itself, and a note handed to another screen changes
  // neither the note list nor this screen — without the tick as an argument
  // the model never re-runs and the note stays put until the next restart.
  function idsForScreen(scr, placementTick, ids) {
    if (!scr) return []
    var fallback = root.screenFor("")
    var isFallback = fallback && fallback.name === scr.name
    var list = ids || root.noteIds
    var out = []
    for (var i = 0; i < list.length; i++) {
      var note = root.noteData(list[i])
      if (!note) continue
      var name = String(note.screen || "")
      if (name === scr.name) out.push(note.id)
      else if (isFallback && !root.screenExists(name)) out.push(note.id)
    }
    return out
  }

  function screenFor(name) {
    var list = Quickshell.screens
    for (var i = 0; i < list.length; i++) if (list[i].name === String(name)) return list[i]
    return list.length > 0 ? list[0] : null
  }

  // The monitor you're actually looking at. screenFor("") falls through to
  // screens[0], so without this every note made from the bar or over IPC
  // lands on the first output no matter which one you're on.
  function focusedScreenName() {
    var monitor = Hyprland.focusedMonitor
    if (monitor && monitor.name) return String(monitor.name)
    var s = root.screenFor("")
    return s ? s.name : ""
  }

  // Seeded in full rather than created empty and patched: the window reads
  // its note once, on completion, and Variants may get there first.
  function addNote(nearId, seed) {
    // Adding a note while everything is hidden would otherwise do nothing
    // visible.
    root.hidden = false
    root.seq += 1
    var id = "n" + root.seq
    var base = nearId ? root.noteData(nearId) : null
    var s = seed || ({})
    root.notes[id] = {
      id: id,
      text: String(s.text || ""),
      x: base ? base.x + 28 : 80,
      y: base ? base.y + 28 : 80,
      w: s.w || (base ? base.w : 260),
      h: s.h || (base ? base.h : 240),
      color: s.color !== undefined ? s.color : (base ? base.color : 0),
      screen: base ? base.screen : root.focusedScreenName()
    }
    root.noteIds = root.noteIds.concat([id])
    saveTimer.restart()
    return id
  }

  readonly property string helpText: [
    "# Cheat sheet",
    "",
    "Click a note to edit its **markdown**, click away to render it.",
    "",
    "- [ ] tick me",
    "- [x] done",
    "",
    "1. numbered lists",
    "2. work too",
    "",
    "`code`, *italic*, **bold**, [links](https://omarchyplugins.com)",
    "",
    "> and quotes",
    "",
    "Header: ● colour · ◀ ▶ move screen · + new · ✕ delete.",
    "Drag the header to move, the corner grip to resize."
  ].join("\n")

  function addHelpNote() {
    return root.addNote(null, { text: root.helpText, w: 340, h: 380, color: 4 })
  }

  function removeNote(id) {
    var key = String(id)
    if (!root.noteData(key)) return
    delete root.notes[key]
    root.noteIds = root.noteIds.filter(function (n) { return n !== key })
    // An empty desktop has no affordance left to make the next note, so the
    // last delete leaves a fresh blank one behind.
    if (root.noteIds.length === 0) root.addNote(null)
    else saveTimer.restart()
  }

  // In place on purpose — see the `notes` comment above.
  function updateNote(id, patch) {
    var note = root.noteData(id)
    if (!note) return
    var moved = false
    for (var key in patch) {
      if (key === "screen" && String(note[key]) !== String(patch[key])) moved = true
      note[key] = patch[key]
    }
    // Once the patch is in, never part-way through it. The tick re-runs every
    // surface's model there and then, and a model that reads the note before
    // the new name is written still sees the old screen: the card is rebuilt
    // on the monitor it just left, holding the position worked out for the one
    // it was dropped on. Which looks exactly like the note springing back.
    if (moved) root.placement++
    saveTimer.restart()
  }

  function load(raw) {
    if (root.loaded) return
    root.loaded = true

    var parsed = null
    try { parsed = JSON.parse(raw) } catch (e) { parsed = null }
    if (parsed && parsed.alwaysOnTop === true) root.alwaysOnTop = true
    if (parsed && parsed.hidden === true) root.hidden = true

    var fallbackScreen = root.screenFor("")
    var list = (parsed && Array.isArray(parsed.notes)) ? parsed.notes : []
    var map = Object.create(null)
    var ids = []
    for (var i = 0; i < list.length; i++) {
      var n = list[i] || {}
      var id = String(n.id || ("n" + (i + 1)))
      if (Object.prototype.hasOwnProperty.call(map, id)) continue
      map[id] = {
        id: id,
        text: String(n.text || ""),
        x: Math.max(0, Math.round(Number(n.x) || 0)),
        y: Math.max(0, Math.round(Number(n.y) || 0)),
        w: Math.max(160, Math.round(Number(n.w) || 260)),
        h: Math.max(120, Math.round(Number(n.h) || 240)),
        color: Math.max(0, Math.min(root.palette.length - 1, Math.round(Number(n.color) || 0))),
        // Resolved now so a note without a screen stops following screens[0]
        // around between restarts.
        screen: String(n.screen || "") || (fallbackScreen ? fallbackScreen.name : "")
      }
      ids.push(id)
      var num = parseInt(id.replace(/^n/, ""), 10)
      if (isFinite(num) && num > root.seq) root.seq = num
    }
    // Anything created between construction and this async read has to
    // survive: the bar widget's New is reachable before the file lands.
    for (var e = 0; e < root.noteIds.length; e++) {
      var pending = root.noteIds[e]
      if (Object.prototype.hasOwnProperty.call(map, pending)) continue
      map[pending] = root.notes[pending]
      ids.push(pending)
    }
    root.notes = map
    root.noteIds = ids
    if (ids.length === 0) root.addNote(null)
  }

  function flush() {
    if (!root.loaded) return
    var out = []
    for (var i = 0; i < root.noteIds.length; i++) {
      var n = root.notes[root.noteIds[i]]
      if (n) out.push(n)
    }
    storeFile.setText(JSON.stringify({
      version: 1,
      alwaysOnTop: root.alwaysOnTop,
      hidden: root.hidden,
      notes: out
    }, null, 2) + "\n")
  }

  Timer {
    id: saveTimer
    interval: 400
    onTriggered: root.flush()
  }

  // The debounce leaves up to 400ms of edits in memory only. Losing them to an
  // ordinary shell restart is not acceptable, so commit on the way out.
  Component.onDestruction: root.flush()

  FileView {
    id: storeFile
    path: root.storePath
    watchChanges: false
    atomicWrites: true
    printErrors: false
    onLoaded: root.load(text())
    // First run: no file yet. Without this the store is never created.
    onLoadFailed: root.load("")
    // Silence on a failed write means a whole session of notes vanishes at
    // restart with nothing anywhere to explain it.
    onSaveFailed: function (error) {
      console.warn("omasticky: could not write " + root.storePath + ": " + error)
    }
  }

  // FileView cannot create the directory, and on a fresh install nothing has
  // written to ~/.local/state/omarchy yet.
  Process {
    command: ["mkdir", "-p", Quickshell.env("HOME") + "/.local/state/omarchy"]
    running: true
  }

  Component.onCompleted: Qt.callLater(function () { storeFile.reload() })

  // --------------------------------------------------------------- windows
  // One surface per screen, not per note. A layer surface allocates a buffer
  // its own size, so a full-desktop surface for every note cost ~8MB each;
  // sharing one per screen makes that constant no matter how many notes.
  //
  // The surface still NEVER moves or resizes — that is what keeps dragging
  // exact. Wayland reports pointer positions surface-relative, so a surface
  // that repositions itself under the pointer feeds its own drag deltas back
  // in and the note skitters. Holding it still makes `nx + mouse.x` an exact
  // pointer position, and only the card inside moves.
  Variants {
    model: Quickshell.screens

    PanelWindow {
      id: surface
      required property var modelData

      readonly property var noteIds: root.idsForScreen(surface.modelData, root.placement, root.noteIds)

      // Cards register themselves so the input mask can follow them. Only
      // changes when a note is added, removed, or handed to another screen.
      property var cards: []

      function addCard(item) {
        var next = surface.cards.slice()
        next.push(item)
        surface.cards = next
      }

      function dropCard(item) {
        surface.cards = surface.cards.filter(function (c) { return c !== item })
      }

      screen: modelData
      visible: !root.hidden && !remapGuard.remapping
      color: "transparent"
      anchors { top: true; bottom: true; left: true; right: true }

      // Hyprland leaves a mapped layer surface at its old global position when
      // its monitor moves in the layout — undock, or rearrange with HyprMon,
      // and the notes keep drawing at the old offset until the shell restarts.
      // The same guard the bar and the wallpaper use.
      ScreenMoveRemap {
        id: remapGuard
        window: surface
      }
      // exclusiveZone 0 reserves nothing but still respects the bar's own
      // zone, so the surface starts below the bar instead of behind it.
      exclusionMode: ExclusionMode.Normal
      exclusiveZone: 0

      WlrLayershell.namespace: "omasticky-note"
      WlrLayershell.layer: root.alwaysOnTop ? WlrLayer.Top : WlrLayer.Bottom
      // ponytail: focus stays claimable at all times. Escape drops the text
      // cursor but the compositor keeps the surface focused until you click
      // elsewhere; toggling keyboardFocus to release it needs a re-click to
      // get back in, which is worse.
      WlrLayershell.keyboardFocus: WlrKeyboardFocus.OnDemand

      // One mask rect per note, so a desktop-sized surface only swallows the
      // clicks that land on an actual note. Instantiator rather than Repeater
      // because a Region is not an Item.
      Instantiator {
        id: maskParts
        model: surface.cards
        delegate: Region {
          required property var modelData
          x: modelData.x
          y: modelData.y
          width: modelData.width
          height: modelData.height
        }
        onObjectAdded: surface.rebuildMask()
        onObjectRemoved: surface.rebuildMask()
      }

      property var maskRegions: []
      function rebuildMask() {
        var parts = []
        for (var i = 0; i < maskParts.count; i++) parts.push(maskParts.objectAt(i))
        surface.maskRegions = parts
      }

      mask: Region { regions: surface.maskRegions }

      // The half of a crossing note that has left its own screen. Deliberately
      // outside `cards`, so it adds nothing to the input mask: the drag that
      // put it here holds a pointer grab on the other surface, and a second
      // surface claiming the same clicks would break it. Skipped on the screen
      // that owns the note, where the real card is already drawing it.
      Image {
        visible: root.dragId !== "" && surface.noteIds.indexOf(root.dragId) === -1
        source: root.dragImage
        cache: false
        x: root.dragGx - (surface.screen ? surface.screen.x : 0)
        y: root.dragGy - (surface.screen ? surface.screen.y : 0)
        width: root.dragW
        height: root.dragH
        z: root.topStack + 1
      }

      Repeater {
        model: surface.noteIds

        Item {
          id: win
          required property var modelData

          // Fills the surface, so `width`/`height` below are the usable area
          // and the card's coordinates are surface coordinates.
          anchors.fill: parent
          z: win.stack

          // Raising on touch is free now that notes on a screen share one
          // scene graph; as separate surfaces the newest always won.
          property int stack: 0
          function raise() { win.stack = ++root.topStack }

          // Releasing the pointer is what normally ends a drag, but the card can
        // go first — plugging a monitor in rebuilds every card, mid-drag or
        // not. Nothing else clears the drag, and the ghost is outside the
        // input mask, so a frozen copy of the note would be left painted on
        // every other screen with no way to click it away.
        Component.onDestruction: {
          if (root.dragId === win.modelData) root.endDrag()
          surface.dropCard(card)
        }

        readonly property var note: root.noteData(win.modelData)
        property int nx: 80
        property int ny: 80
        property int nw: 260
        property int nh: 240
        property int ci: 0
        property bool armedForDelete: false
        property string nscreen: ""
        // Where the pointer was, in layout coordinates, on the last drag event.
        // A note is handed to whichever screen you dropped the cursor over.
        // Seeded on press so a click that never moves settles where it already
        // is, instead of teleporting to whichever screen contains (0, 0).
        property int pointerGx: 0
        property int pointerGy: 0
        function trackPointer(mx, my) {
          win.pointerGx = (surface.screen ? surface.screen.x : 0) + win.nx + mx
          win.pointerGy = (surface.screen ? surface.screen.y : 0) + win.ny + my
        }
        function dragTo(lx, ly) {
          var sx = surface.screen ? surface.screen.x : 0
          var sy = surface.screen ? surface.screen.y : 0
          var b = Model.bounds(Quickshell.screens)
          // Clamped across the whole layout, not this screen: a note has to be
          // able to cross a monitor edge, but not vanish off the desktop. The
          // bar's strip is taken off the far edges so the drag can't push the
          // card past the surface and snap back on release.
          var insetW = surface.screen ? surface.screen.width - win.width : 0
          var insetH = surface.screen ? surface.screen.height - win.height : 0
          win.nx = Math.max(b.x1, Math.min(lx + sx, b.x2 - insetW - win.nw)) - sx
          win.ny = Math.max(b.y1, Math.min(ly + sy, b.y2 - insetH - win.nh)) - sy
        }
        // Where the card now is in layout coordinates, so the screens it is
        // sliding onto can draw the part this surface has clipped away.
        function publishDrag() {
          root.dragGx = (surface.screen ? surface.screen.x : 0) + win.nx
          root.dragGy = (surface.screen ? surface.screen.y : 0) + win.ny
        }
        function settle() {
          root.endDrag()
          var from = surface.screen
          if (!from) return
          // The bar's strip is identical on every output, so measuring it here
          // carries over to the screen we're moving to.
          var insetW = from.width - win.width
          var insetH = from.height - win.height
          var to = Model.screenForDrop(Quickshell.screens, win.pointerGx, win.pointerGy, insetW, insetH) || from
          var placed = Model.relocate(win.nx, win.ny, win.nw, win.nh,
            { x: from.x, y: from.y },
            {
              x: to.x,
              y: to.y,
              usableW: to.width - insetW,
              usableH: to.height - insetH
            })
          // Position first, screen last. Handing the note over rebuilds it on
          // the other surface from what is stored *at that moment*, and tears
          // this delegate down on the way — so a position written afterwards
          // is written to a card that no longer exists, and the note arrives
          // still holding the coordinates it was dragged to on the old screen.
          win.nx = placed.x
          win.ny = placed.y
          if (to.name !== from.name) win.nscreen = to.name
        }
        // Hand the note to the next screen along without a pointer grab, for
        // when dragging it across is more trouble than it is worth — a note
        // parked at the far edge of a wide monitor, say.
        readonly property var leftScreen: Model.adjacentScreen(Quickshell.screens, surface.screen, -1)
        readonly property var rightScreen: Model.adjacentScreen(Quickshell.screens, surface.screen, 1)
        // Unlike a drag, which lands where you dropped it, an arrow keeps the
        // note where it sits *on the screen* — same spot on the next monitor.
        // Re-expressing the layout position instead would clamp every note to
        // x=0 and pile them against the shared edge.
        function moveToScreen(to) {
          var from = surface.screen
          if (!from || !to) return
          var placed = Model.clampOnto(win.nx, win.ny, win.nw, win.nh,
            to.width - (from.width - win.width),
            to.height - (from.height - win.height))
          win.nx = placed.x
          win.ny = placed.y
          win.nscreen = to.name
        }
        // Raw markdown. The note shows it rendered, and swaps to a plain-text
        // editor over the same string while you're typing, so Qt never gets to
        // round-trip and rewrite the source.
        property string source: ""
        property bool editing: false
        function followLink(link) {
          var s = String(link)
          if (s.indexOf("toggle:") !== 0) {
            root.openLink(s)
            return
          }
          var next = Model.toggleTask(win.source, parseInt(s.slice(7), 10))
          if (next === win.source) return
          win.source = next
          body.text = next
          root.updateNote(win.modelData, { text: next })
        }
        readonly property color paper: root.palette[Math.min(ci, root.palette.length - 1)]
        readonly property color pen: root.ink(paper)
        readonly property bool dark: pen === Qt.color("#f2f2f2")
        readonly property color headerPaper: dark ? Qt.lighter(paper, 1.4) : Qt.darker(paper, 1.07)
        function clampX(v) { return Math.max(0, Math.min(v, Math.max(0, win.width - win.nw))) }
        function clampY(v) { return Math.max(0, Math.min(v, Math.max(0, win.height - win.nh))) }
        Component.onCompleted: {
          surface.addCard(card)
          if (!note) return
          nx = note.x
          ny = note.y
          nw = note.w
          nh = note.h
          ci = note.color
          nscreen = note.screen
          win.source = note.text
          body.text = note.text
        }
        onEditingChanged: if (editing) body.forceActiveFocus()
        onNxChanged: root.updateNote(win.modelData, { x: nx })
        onNyChanged: root.updateNote(win.modelData, { y: ny })
        onNwChanged: root.updateNote(win.modelData, { w: nw })
        onNhChanged: root.updateNote(win.modelData, { h: nh })
        onCiChanged: root.updateNote(win.modelData, { color: ci })
        onNscreenChanged: root.updateNote(win.modelData, { screen: nscreen })
        // A note saved on a wider monitor, or budded off one near the right
        // edge, can restore completely outside the surface: not drawn, not
        // clickable, recoverable only by editing the JSON. Pull those back.
        //
        // Guarded on width, and only for notes with nothing left on screen:
        // before the surface is configured `width` is 0, and clamping against
        // that collapses every note onto the origin.
        function rescueOffscreen() {
          if (win.width <= 0 || win.height <= 0) return
          if (win.nx + win.nw > 0 && win.ny + win.nh > 0
            && win.nx < win.width && win.ny < win.height) return
          win.nx = win.clampX(win.nx)
          win.ny = win.clampY(win.ny)
        }
        // The surface reports its real size only once the compositor has
        // configured it, which is after Component.onCompleted.
        onWidthChanged: win.rescueOffscreen()
        onHeightChanged: win.rescueOffscreen()

        Rectangle {
          id: card
            x: win.nx
            y: win.ny
            width: win.nw
            height: win.nh
            color: win.paper
            radius: Style.cornerRadius
            border.width: 1
            border.color: win.dark ? Qt.lighter(win.paper, 1.6) : Qt.darker(win.paper, 1.25)

            // ------------------------------------------------------- header
            Rectangle {
              id: header
              anchors { top: parent.top; left: parent.left; right: parent.right }
              height: 24
              radius: Style.cornerRadius
              color: win.headerPaper

              // Square off the bottom corners the radius above rounded.
              Rectangle {
                anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
                height: Math.max(1, Style.cornerRadius)
                color: parent.color
              }

              MouseArea {
                id: dragArea
                anchors.fill: parent
                cursorShape: pressed ? Qt.ClosedHandCursor : Qt.OpenHandCursor
                // `win.nx + m.x` is the pointer in surface coordinates, and the
                // surface never moves, so this is exact on every event.
                property real ox: 0
                property real oy: 0
                onPressed: function (m) { ox = m.x; oy = m.y; win.raise(); win.trackPointer(m.x, m.y) }
                onPositionChanged: function (m) {
                  if (!pressed) return
                  // Read the pointer before moving the card — afterwards m.x is
                  // measured against the new position.
                  win.trackPointer(m.x, m.y)
                  win.dragTo(Math.round(win.nx + m.x - ox), Math.round(win.ny + m.y - oy))
                  // Here rather than on press: grabbing the card costs a
                  // render to texture, and most presses on a header are a
                  // click to raise the note, not a drag.
                  if (root.dragId !== win.modelData) root.beginDrag(win.modelData, card, win.nw, win.nh)
                  win.publishDrag()
                }
                onReleased: win.settle()
                onCanceled: win.settle()
              }

              Row {
                anchors { right: parent.right; verticalCenter: parent.verticalCenter; rightMargin: 4 }
                spacing: 2

                component HeaderButton: Rectangle {
                  property alias glyph: label.text
                  property color glyphColor: win.pen
                  signal activated
                  width: 20
                  height: 20
                  radius: 3
                  color: hover.containsMouse ? Qt.rgba(win.pen.r, win.pen.g, win.pen.b, 0.12) : "transparent"
                  Text {
                    id: label
                    anchors.centerIn: parent
                    color: parent.glyphColor
                    font.family: Style.font.family
                    font.pixelSize: Style.font.body
                  }
                  MouseArea {
                    id: hover
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: parent.activated()
                  }
                }

                HeaderButton {
                  glyph: "●"
                  glyphColor: win.dark ? "#f2f2f2" : Qt.darker(win.paper, 1.9)
                  onActivated: win.ci = (win.ci + 1) % root.palette.length
                }
                // Only where there is actually a screen to move to, so a
                // single-monitor desktop never sees them.
                HeaderButton {
                  glyph: "◀"
                  visible: !!win.leftScreen
                  onActivated: win.moveToScreen(win.leftScreen)
                }
                HeaderButton {
                  glyph: "▶"
                  visible: !!win.rightScreen
                  onActivated: win.moveToScreen(win.rightScreen)
                }
                HeaderButton {
                  glyph: "+"
                  onActivated: root.addNote(win.modelData)
                }
                HeaderButton {
                  glyph: win.armedForDelete ? "✕?" : "✕"
                  glyphColor: win.armedForDelete ? "#c0392b" : win.pen
                  // A note with text costs a confirmation; an empty one doesn't.
                  onActivated: {
                    if (win.source.length === 0 || win.armedForDelete) root.removeNote(win.modelData)
                    else { win.armedForDelete = true; disarm.restart() }
                  }
                }
              }

              Timer {
                id: disarm
                interval: 3000
                onTriggered: win.armedForDelete = false
              }
            }

            // --------------------------------------------------------- body
            Flickable {
              id: flick
              anchors {
                top: header.bottom
                left: parent.left
                right: parent.right
                bottom: parent.bottom
                margins: 10
              }
              clip: true
              contentWidth: width
              contentHeight: win.editing ? body.implicitHeight : Math.max(rendered.implicitHeight, 20)
              interactive: contentHeight > height
              boundsBehavior: Flickable.StopAtBounds

              function ensureVisible(r) {
                if (contentY >= r.y) contentY = r.y
                else if (contentY + height <= r.y + r.height) contentY = r.y + r.height - height
              }

              Text {
                id: rendered
                visible: !win.editing
                width: flick.width
                wrapMode: Text.Wrap
                textFormat: Text.MarkdownText
                // Skipped while editing: the editor covers it, and re-parsing
                // the whole document on every keystroke is not free.
                text: win.editing ? "" : Model.renderMarkdown(win.source)
                color: win.pen
                linkColor: win.dark ? "#8ab4f8" : "#12489c"
                font.family: Style.font.family
                font.pixelSize: Style.font.subtitle
              }

              // Sits above `rendered` and does its own link hit-testing, rather
              // than relying on which presses a Text does and doesn't accept.
              MouseArea {
                width: flick.width
                height: Math.max(flick.height, flick.contentHeight)
                visible: !win.editing
                hoverEnabled: true
                cursorShape: rendered.linkAt(mouseX, mouseY) ? Qt.PointingHandCursor : Qt.IBeamCursor
                onClicked: function (m) {
                  win.raise()
                  var link = rendered.linkAt(m.x, m.y)
                  if (link) win.followLink(link)
                  else win.editing = true
                }
              }

              Text {
                visible: !win.editing && win.source.length === 0
                text: "Take a note…"
                color: Qt.rgba(win.pen.r, win.pen.g, win.pen.b, 0.4)
                font.family: Style.font.family
                font.pixelSize: Style.font.subtitle
              }

              TextEdit {
                id: body
                visible: win.editing
                width: flick.width
                wrapMode: TextEdit.Wrap
                selectByMouse: true
                persistentSelection: true
                color: win.pen
                selectionColor: Qt.rgba(win.pen.r, win.pen.g, win.pen.b, 0.25)
                selectedTextColor: win.pen
                font.family: Style.font.family
                font.pixelSize: Style.font.subtitle
                onTextChanged: {
                  win.source = text
                  root.updateNote(win.modelData, { text: text })
                }
                onCursorRectangleChanged: if (win.editing) flick.ensureVisible(cursorRectangle)
                onActiveFocusChanged: if (!activeFocus) win.editing = false
                Keys.onEscapePressed: win.editing = false
              }
            }

            // --------------------------------------------------- resize grip
            MouseArea {
              anchors { right: parent.right; bottom: parent.bottom }
              width: 16
              height: 16
              cursorShape: Qt.SizeFDiagCursor
              property real ox: 0
              property real oy: 0
              onPressed: function (m) { ox = m.x; oy = m.y }
              onPositionChanged: function (m) {
                if (!pressed) return
                win.nw = Math.max(180, Math.min(win.width - win.nx, Math.round(win.nw + m.x - ox)))
                win.nh = Math.max(120, Math.min(win.height - win.ny, Math.round(win.nh + m.y - oy)))
              }

              // Three rotated hairlines. A Canvas here would cost an offscreen
              // paint device and a JS paint callback per note for the same marks.
              Repeater {
                model: [4, 8, 12]
                Rectangle {
                  required property int modelData
                  width: modelData * 1.1
                  height: 1
                  color: Qt.rgba(win.pen.r, win.pen.g, win.pen.b, 0.35)
                  x: parent.width - 1 - width / 2 - modelData / 2
                  y: parent.height - 1 - modelData / 2
                  rotation: -45
                }
              }
            }
          }
        }
      }
    }
  }
}
