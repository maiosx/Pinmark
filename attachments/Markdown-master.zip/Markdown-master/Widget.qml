import QtQuick
import qs.Commons
import qs.Ui

// Bar entry point: an icon that opens a popup with the board-level actions.
// The notes themselves live in the service (Service.qml); this only ever
// calls into it.
Panel {
  id: root
  moduleName: "io.github.huligabuliga.omasticky"
  ipcTarget: "io.github.huligabuliga.omasticky"

  // The bar host doesn't inject plugin services into widgets, but it does get
  // handed the shell root, which owns them.
  readonly property var notes: bar && bar.shell && bar.shell.serviceFor
    // moduleName, not a literal: after `omarchy plugin clone` the bar
    // injects the clone's id and a hardcoded one resolves to nothing.
    ? bar.shell.serviceFor(root.moduleName)
    : null

  readonly property bool boardHidden: notes ? notes.hidden : false
  readonly property int noteCount: notes ? notes.noteIds.length : 0
  // Escaped, not a literal: the Nerd Font glyph is a private-use
  // codepoint and does not survive every editor round-trip.
  readonly property string icon: "\uf249"
  readonly property string statusText: boardHidden
    ? "Hidden"
    : (noteCount === 1 ? "1 note" : noteCount + " notes")

  implicitWidth: button.implicitWidth
  implicitHeight: button.implicitHeight

  function newNote() {
    if (!notes) return
    notes.addNote(null, null)
    close()
  }

  function newHelpNote() {
    if (!notes) return
    notes.addHelpNote()
    close()
  }

  function toggleBoard() {
    if (notes) notes.toggleHidden()
  }

  BarIconButton {
    id: button
    anchors.fill: parent
    bar: root.bar
    text: root.icon
    slotSize: Style.bar.statusSlot
    dimmed: root.boardHidden
    active: root.opened
    tooltipText: "Sticky notes — " + root.statusText.toLowerCase()
    onPressed: function (mouseButton) {
      // Right click keeps the one-keystroke hide that predates this popup.
      if (mouseButton === Qt.RightButton) root.toggleBoard()
      else root.toggle()
    }
  }

  KeyboardPanel {
    id: panel
    anchorItem: button
    owner: root
    bar: root.bar
    open: root.opened
    focusTarget: keyCatcher
    contentWidth: panel.fittedContentWidth(Style.space(280))
    contentHeight: panel.fittedContentHeight(column.implicitHeight)

    PanelKeyCatcher {
      id: keyCatcher
      anchors.fill: parent
      onCloseRequested: root.close()
      onTabRequested: function (direction) { root.switchPanel(direction) }
      onActivateRequested: root.newNote()

      Column {
        id: column
        anchors { left: parent.left; right: parent.right; top: parent.top }
        spacing: Style.space(14)

        // ---------- Hero: icon · title/status · count ----------
        Item {
          width: parent.width
          implicitHeight: Math.max(heroIcon.implicitHeight, heroLabels.implicitHeight, heroCount.implicitHeight)

          Text {
            id: heroIcon
            text: root.icon
            color: root.bar.foreground
            font.family: root.bar.fontFamily
            font.pixelSize: Style.font.display
            anchors.left: parent.left
            anchors.verticalCenter: parent.verticalCenter
          }

          Column {
            id: heroLabels
            anchors.left: heroIcon.right
            anchors.leftMargin: Style.space(14)
            anchors.right: heroCount.left
            anchors.rightMargin: Style.space(10)
            anchors.verticalCenter: parent.verticalCenter
            spacing: Style.space(2)

            Text {
              text: "Omasticky"
              color: root.bar.foreground
              font.family: root.bar.fontFamily
              font.pixelSize: Style.font.title
              font.bold: true
              elide: Text.ElideRight
              width: parent.width
            }

            Text {
              text: root.statusText.toUpperCase()
              color: Qt.darker(root.bar.foreground, 1.4)
              font.family: root.bar.fontFamily
              font.pixelSize: Style.font.caption
              font.bold: true
              font.letterSpacing: 1.2
              elide: Text.ElideRight
              width: parent.width
            }
          }

          Text {
            id: heroCount
            text: root.noteCount
            color: root.bar.foreground
            opacity: root.boardHidden ? 0.4 : 1
            font.family: root.bar.fontFamily
            font.pixelSize: Style.font.displayLarge
            font.bold: true
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
          }
        }

        PanelSeparator {
          foreground: root.bar.foreground
        }

        // ---------- Controls ----------
        Row {
          width: parent.width
          spacing: Style.space(6)

          Button {
            width: (parent.width - parent.spacing * 2) / 3
            text: "New"
            foreground: root.bar.foreground
            fontFamily: root.bar.fontFamily
            horizontalPadding: Style.spacing.controlPaddingX
            verticalPadding: Style.spacing.controlPaddingY
            bordered: true
            onClicked: root.newNote()
          }

          Button {
            width: (parent.width - parent.spacing * 2) / 3
            text: root.boardHidden ? "Show" : "Hide"
            foreground: root.bar.foreground
            fontFamily: root.bar.fontFamily
            horizontalPadding: Style.spacing.controlPaddingX
            verticalPadding: Style.spacing.controlPaddingY
            bordered: true
            active: root.boardHidden
            onClicked: root.toggleBoard()
          }

          Button {
            width: (parent.width - parent.spacing * 2) / 3
            text: "Help"
            foreground: root.bar.foreground
            fontFamily: root.bar.fontFamily
            horizontalPadding: Style.spacing.controlPaddingX
            verticalPadding: Style.spacing.controlPaddingY
            bordered: true
            onClicked: root.newHelpNote()
          }
        }

        Text {
          width: parent.width
          wrapMode: Text.Wrap
          text: root.boardHidden
            ? "Notes are hidden. Show them, or add one to bring them back."
            : "Help drops a cheat-sheet note on the desktop."
          color: root.bar.foreground
          opacity: 0.6
          font.family: root.bar.fontFamily
          font.pixelSize: Style.font.bodySmall
        }
      }
    }
  }
}
